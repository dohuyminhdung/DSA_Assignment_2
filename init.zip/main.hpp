#ifndef DSA232_A1_MAIN_H
#define DSA232_A1_MAIN_H

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iomanip>
#include <string>
#include <cstring>
#include <sstream>
#include <fstream>
#include <cassert>
#include <vector>
#include <list>

using namespace std;
#endif //DSA232_A1_MAIN_H